#include <stdio.h>

int
main(int argc, char *argv[]) {
    printf "Programmaufruf!\n");
    return 0;
}
